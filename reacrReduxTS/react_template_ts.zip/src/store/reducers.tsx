import { combineReducers } from 'redux';

import mainReducer from '../pages/main/reducer';

const rootReducer = combineReducers({
    main: mainReducer,
});

export type RootReducerType = typeof rootReducer;
export type RootStateType = ReturnType<RootReducerType>;

export default rootReducer;
